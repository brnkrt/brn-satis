@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kurulum.ps1" -Profil arvenato
pause
