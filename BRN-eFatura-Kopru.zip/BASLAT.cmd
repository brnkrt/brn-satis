@echo off
start "" wscript.exe "%~dp0gizli-baslat.vbs"
