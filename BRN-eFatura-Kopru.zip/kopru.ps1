﻿# BRN e-Fatura Köprüsü
# BRN Satış Programı ile Trendyol e-Faturam arasında aracılık eder. Bu bilgisayarda çalışır çünkü
# Trendyol e-Faturam API'si yalnızca izin verilen (whitelist) internet adresinden gelen istekleri kabul eder.
#
# - Yalnızca bu bilgisayardan (localhost:8796) ve yalnızca BRN'nin sayfasından gelen istekleri kabul eder.
# - Trendyol giriş bilgileri %APPDATA%\BRN-eFatura\ayar.json içinde Windows DPAPI ile şifreli durur;
#   yalnızca bu Windows kullanıcısı çözebilir. Bilgiler kurulum.ps1 ile girilir.
# - Fatura içeriğini BRN hazırlar; köprü yalnızca firma/kullanıcı kimliğini ekleyip Trendyol'a iletir.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$SURUM = '1.4'
$PORT = 8796
# Her program kendi Trendyol hesabını kullanır: istek hangi sayfadan geldiyse o hesabın bilgileri seçilir.
$PROFILLER = [ordered]@{
  'brn'      = @{ dosya = 'ayar.json';          kurulum = 'KURULUM.cmd';          kaynaklar = @('https://brnkrt.github.io', 'http://localhost:8791') }
  'arvenato' = @{ dosya = 'ayar-arvenato.json'; kurulum = 'KURULUM-ARVENATO.cmd'; kaynaklar = @('https://arvenato.github.io', 'http://localhost:8792') }
}
$IZINLI = @($PROFILLER.Values | ForEach-Object { $_.kaynaklar })
$script:profil = 'brn'
$klasor = Join-Path $env:APPDATA 'BRN-eFatura'
$logYol = Join-Path $klasor 'kopru.log'
New-Item -ItemType Directory -Force $klasor | Out-Null

function Log([string]$m) {
  try { Add-Content -Path $logYol -Value ('{0:yyyy-MM-dd HH:mm:ss} {1}' -f (Get-Date), $m) -Encoding UTF8 } catch {}
}
function AyarYol { return (Join-Path $klasor $PROFILLER[$script:profil].dosya) }
function AyarOku {
  $y = AyarYol
  if (-not (Test-Path $y)) { throw ('Köprü bu program için kurulmamış: önce ' + $PROFILLER[$script:profil].kurulum + ' çalıştırılmalı.') }
  return (Get-Content -Raw -Encoding UTF8 $y | ConvertFrom-Json)
}
# Her hesabın giriş anahtarı ayrı tutulur
$script:oturumlar = @{}
function OturumYukle {
  if (-not $script:oturumlar.ContainsKey($script:profil)) { $script:oturumlar[$script:profil] = @{ tok = $null; zaman = [datetime]::MinValue; kimlik = $null } }
  $o = $script:oturumlar[$script:profil]
  $script:tok = $o.tok; $script:tokZaman = $o.zaman; $script:kimlik = $o.kimlik
}
function OturumKaydet { $script:oturumlar[$script:profil] = @{ tok = $script:tok; zaman = $script:tokZaman; kimlik = $script:kimlik } }
function Taban($a) {
  if ($env:BRN_EFK_TABAN) { return $env:BRN_EFK_TABAN }   # yalnızca geliştirme denemesi için (sahte sunucu)
  if ($a.ortam -eq 'canli') { return 'https://apigateway.trendyolecozum.com' }
  return 'https://stage-apigateway.trendyolefaturam.com'
}
function SifreCoz([string]$s) {
  $ss = ConvertTo-SecureString $s
  $p = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p) }
}
# Trendyol'a HTTP isteği (gövde UTF-8). Hata kodlarında da yanıt gövdesi döner.
function Istek([string]$yontem, [string]$url, $govde, [string]$token) {
  $req = [Net.HttpWebRequest]::Create($url)
  $req.Method = $yontem; $req.Accept = 'application/json, text/plain, */*'; $req.Timeout = 90000; $req.UserAgent = 'BRN-eFatura-Kopru/' + $SURUM
  if ($token) { $req.Headers.Add('Authorization', $token) }
  if ($null -ne $govde) {
    $b = [Text.Encoding]::UTF8.GetBytes([string]$govde)
    $req.ContentType = 'application/json; charset=utf-8'; $req.ContentLength = $b.Length
    $s = $req.GetRequestStream(); $s.Write($b, 0, $b.Length); $s.Close()
  }
  try { $res = $req.GetResponse() } catch [Net.WebException] { $res = $_.Exception.Response; if (-not $res) { throw ("Trendyol'a ulaşılamadı: " + $_.Exception.Message) } }
  $sr = New-Object IO.StreamReader($res.GetResponseStream(), [Text.Encoding]::UTF8); $metin = $sr.ReadToEnd(); $sr.Close()
  $bas = @{}; foreach ($k in $res.Headers.AllKeys) { $bas[$k] = $res.Headers[$k] }
  $kod = [int]$res.StatusCode; $res.Close()
  return @{ kod = $kod; metin = $metin; basliklar = $bas }
}
function JwtCoz([string]$t) {
  $p = ($t -replace '^Bearer\s+', '').Split('.')[1].Replace('-', '+').Replace('_', '/')
  while ($p.Length % 4) { $p += '=' }
  return ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p)) | ConvertFrom-Json)
}
# Büyük/küçük harf duyarsız eşleşme — Türkçe "I/ı" sorununa karşı dilden bağımsız
function Eslesir([string]$s, [string]$desen) { return [regex]::IsMatch($s, $desen, [Text.RegularExpressions.RegexOptions]'IgnoreCase, CultureInvariant') }
# Token içinde firma/kullanıcı kimliğini arar (alan adları büyük/küçük harf ve iç içe olabilir)
function KimlikBul($o, [string]$desen) {
  if ($null -eq $o) { return $null }
  foreach ($p in $o.PSObject.Properties) {
    if ((Eslesir $p.Name $desen) -and ($p.Value -is [ValueType] -or $p.Value -is [string]) -and "$($p.Value)" -match '^\d+$') { return [int64]$p.Value }
  }
  foreach ($p in $o.PSObject.Properties) { if ($p.Value -is [PSCustomObject]) { $v = KimlikBul $p.Value $desen; if ($null -ne $v) { return $v } } }
  return $null
}
$script:tok = $null; $script:tokZaman = [datetime]::MinValue; $script:kimlik = $null
function Giris([switch]$zorla) {
  if (-not $zorla -and $script:tok -and ((Get-Date) - $script:tokZaman).TotalMinutes -lt 20) { return }
  $a = AyarOku
  $g = @{ email = $a.email; password = (SifreCoz $a.sifre) } | ConvertTo-Json -Compress
  $r = Istek 'POST' ((Taban $a) + '/api/auth/signin') $g $null
  $g = $null
  if ($r.kod -eq 403) { throw 'Trendyol bu internet adresinden gelen isteği engelledi (403). Bilgisayarın internet adresi değişmiş olabilir; portalda izinli IP adresini kontrol edin.' }
  if ($r.kod -ne 200) { throw ('Trendyol girişi başarısız (' + $r.kod + '). E-posta/şifreyi KURULUM.cmd ile yeniden girin. ' + $r.metin) }
  $t = $null
  foreach ($k in $r.basliklar.Keys) { if ((Eslesir $k 'access') -and -not (Eslesir $k 'refresh|control|expose|allow')) { $t = $r.basliklar[$k] } }
  if (-not $t -and $r.basliklar['Authorization']) { $t = $r.basliklar['Authorization'] }
  if (-not $t) { try { $j = $r.metin | ConvertFrom-Json; if ($j.accessToken) { $t = $j.accessToken } elseif ($j.token) { $t = $j.token } } catch {} }
  if (-not $t) { throw ('Giriş yanıtında erişim anahtarı bulunamadı. Başlıklar: ' + (($r.basliklar.Keys) -join ', ')) }
  if ($t -notmatch '^Bearer ') { $t = 'Bearer ' + $t }
  $c = JwtCoz $t
  $cid = KimlikBul $c '^(company_?id|companyid|cid)$'
  $uid = KimlikBul $c '^(user_?id|userid|uid)$'
  if ($null -eq $uid) { $uid = KimlikBul $c '^sub$' }
  # Trendyol firma numarasını yetki listesinin anahtarı olarak verir: privs = { "<firmaId>": ["EARCHIVE_WRITE", ...] }
  if ($null -eq $cid -and $c.privs) {
    foreach ($p in $c.privs.PSObject.Properties) { if ($p.Name -match '^\d+$' -and (@($p.Value) -contains 'EARCHIVE_WRITE' -or @($p.Value) -contains 'OUTGOING_EINVOICE_WRITE')) { $cid = [int64]$p.Name; break } }
    if ($null -eq $cid) { foreach ($p in $c.privs.PSObject.Properties) { if ($p.Name -match '^\d+$') { $cid = [int64]$p.Name; break } } }
  }
  $script:tok = $t; $script:tokZaman = Get-Date
  $script:kimlik = @{ companyId = $cid; userId = $uid; alanlar = (($c.PSObject.Properties.Name) -join ','); yapi = (($c | Select-Object * -ExcludeProperty eml, email) | ConvertTo-Json -Depth 6 -Compress) }
  OturumKaydet
  Log ("Giriş tamam [{3}] ({0}) companyId={1} userId={2}" -f $a.ortam, $cid, $uid, $script:profil)
}
# Kimlik gerektiren Trendyol isteği; anahtar süresi dolmuşsa bir kez yeniden giriş yapar
function TrendyolIstek([string]$yontem, [string]$yol, $govde) {
  Giris
  $a = AyarOku
  $r = Istek $yontem ((Taban $a) + $yol) $govde $script:tok
  if ($r.kod -eq 401) { Giris -zorla; $r = Istek $yontem ((Taban $a) + $yol) $govde $script:tok }
  return $r
}
# Fatura arama isteği gövdesi (tarihler yyyy-MM-dd; sayfa 0'dan başlar)
function AramaGovde($g) {
  $b = [ordered]@{ companyId = $script:kimlik.companyId; pagination = @{ page = [int]$g.sayfa; size = 100 } }
  if ($g.baslangic) { $b.startDate = [string]$g.baslangic }
  if ($g.bitis) { $b.endDate = [string]$g.bitis }
  return (JsonMetin $b)
}
function YanitGovde($r) { if ($r.metin -match '^\s*[\{\[]') { return $r.metin } else { return (JsonMetin $r.metin) } }
function KimlikEkle([string]$json) {
  if ($null -eq $script:kimlik.companyId -or $null -eq $script:kimlik.userId) { throw ('Firma/kullanıcı kimliği bulunamadı. Token alanları: ' + $script:kimlik.alanlar) }
  $json = [regex]::Replace($json, '"companyId"\s*:\s*0\b', '"companyId":' + $script:kimlik.companyId)
  $json = [regex]::Replace($json, '"userId"\s*:\s*0\b', '"userId":' + $script:kimlik.userId)
  return $json
}
function JsonMetin($o) { return ($o | ConvertTo-Json -Depth 10 -Compress) }

function Yanit($ctx, [int]$kod, [string]$json) {
  $res = $ctx.Response
  $origin = $ctx.Request.Headers['Origin']
  if ($IZINLI -contains $origin) {
    $res.AddHeader('Access-Control-Allow-Origin', $origin)
    $res.AddHeader('Vary', 'Origin')
    $res.AddHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $res.AddHeader('Access-Control-Allow-Headers', 'Content-Type')
    $res.AddHeader('Access-Control-Allow-Private-Network', 'true')
    $res.AddHeader('Access-Control-Max-Age', '600')
  }
  $res.StatusCode = $kod
  if ($null -ne $json) {
    $b = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $b.Length
    $res.OutputStream.Write($b, 0, $b.Length)
  }
  $res.Close()
}
function YanitBayt($ctx, [byte[]]$bayt, [string]$tur) {
  $res = $ctx.Response
  $origin = $ctx.Request.Headers['Origin']
  if ($IZINLI -contains $origin) { $res.AddHeader('Access-Control-Allow-Origin', $origin); $res.AddHeader('Vary', 'Origin'); $res.AddHeader('Access-Control-Allow-Private-Network', 'true') }
  $res.StatusCode = 200; $res.ContentType = $tur; $res.ContentLength64 = $bayt.Length
  $res.OutputStream.Write($bayt, 0, $bayt.Length); $res.Close()
}
function Isle($ctx) {
  $q = $ctx.Request
  $origin = $q.Headers['Origin']
  if ($q.HttpMethod -eq 'OPTIONS') { Yanit $ctx 204 $null; return }
  # Yalnızca BRN sayfası kullanabilir (başka web siteleri bu köprüyü çağıramaz)
  if (-not ($IZINLI -contains $origin)) { Yanit $ctx 403 (JsonMetin @{ hata = 'İzin verilmeyen kaynak' }); return }
  foreach ($k in $PROFILLER.Keys) { if ($PROFILLER[$k].kaynaklar -contains $origin) { $script:profil = $k; break } }
  OturumYukle
  $govde = $null
  if ($q.HasEntityBody) { $sr = New-Object IO.StreamReader($q.InputStream, [Text.Encoding]::UTF8); $govde = $sr.ReadToEnd(); $sr.Close() }
  $yol = $q.Url.AbsolutePath.TrimEnd('/')
  switch ($yol) {
    '/durum' {
      $a = $null; try { $a = AyarOku } catch {}
      $e = if ($a) { $a.email -replace '^(.{2}).*(@.*)$', '$1***$2' } else { '' }
      Yanit $ctx 200 (JsonMetin @{ ok = $true; surum = $SURUM; profil = $script:profil; kurulu = [bool]$a; ortam = $(if ($a) { $a.ortam } else { '' }); eposta = $e })
    }
    '/gelen' {
      # Gelen e-Faturaları listeler (Trendyol'a ulaşan, bize kesilmiş faturalar)
      $g = $(if ($govde) { $govde | ConvertFrom-Json } else { @{} })
      Giris
      $r = TrendyolIstek 'POST' '/api/invoice/documents/incoming-einvoice/search' (AramaGovde $g)
      Yanit $ctx 200 ('{"kod":' + $r.kod + ',"yanit":' + (YanitGovde $r) + '}')
    }
    '/giden' {
      # Bizim kestiğimiz faturalar (e-Fatura ve e-Arşiv). Trendyol bu listeyi belgelerinde yazmıyor; olan uç noktalar denenir.
      $g = $(if ($govde) { $govde | ConvertFrom-Json } else { @{} })
      Giris
      $b = AramaGovde $g
      $ef = TrendyolIstek 'POST' '/api/invoice/documents/outgoing-einvoice/search' $b
      $ea = TrendyolIstek 'POST' '/api/invoice/documents/earchive/search' $b
      Yanit $ctx 200 ('{"efatura":{"kod":' + $ef.kod + ',"yanit":' + (YanitGovde $ef) + '},"earsiv":{"kod":' + $ea.kod + ',"yanit":' + (YanitGovde $ea) + '}}')
    }
    '/giris' {
      Giris -zorla
      Yanit $ctx 200 (JsonMetin @{ ok = $true; companyId = $script:kimlik.companyId; userId = $script:kimlik.userId; alanlar = $script:kimlik.alanlar; yapi = $script:kimlik.yapi })
    }
    '/mukellef' {
      $vkn = ($govde | ConvertFrom-Json).vkn
      if ("$vkn" -notmatch '^\d{10,11}$') { Yanit $ctx 400 (JsonMetin @{ hata = 'VKN/TCKN hatalı' }); return }
      $r = TrendyolIstek 'GET' ('/api/invoice/taxpayers/' + $vkn) $null
      Yanit $ctx $r.kod $(if ($r.metin) { $r.metin } else { '[]' })
    }
    '/kes' {
      $g = $govde | ConvertFrom-Json
      $yolT = if ($g.tip -eq 'EFATURA') { '/api/invoice/documents/outgoing-einvoice' } else { '/api/invoice/documents/earchive' }
      Giris
      $json = KimlikEkle ([string]$g.govde)
      Log ("Fatura gönderiliyor: {0} {1}" -f $g.tip, $g.ref)
      $r = TrendyolIstek 'POST' $yolT $json
      Log ("Yanıt {0}: {1}" -f $r.kod, ($r.metin.Substring(0, [Math]::Min(300, $r.metin.Length))))
      $ortam = (AyarOku).ortam
      Yanit $ctx 200 ('{"kod":' + $r.kod + ',"ortam":"' + $ortam + '","yanit":' + $(if ($r.metin -match '^\s*[\{\[]') { $r.metin } else { (JsonMetin $r.metin) }) + '}')
    }
    '/pdf' {
      # Fatura PDF'ini indirip BRN'ye dosya olarak verir (BRN yazdırmak için kullanır)
      $g = $govde | ConvertFrom-Json
      Giris
      $istek = JsonMetin @{ documentType = $(if ($g.tip -eq 'EFATURA') { 'EINVOICE' } elseif ($g.tip -eq 'GELEN') { 'INCOMING_EINVOICE' } else { 'EARCHIVE' }); fileExtension = 'pdf'; documentUuid = $g.uuid; companyId = $script:kimlik.companyId; inline = $true; envelope = $false }
      $r = TrendyolIstek 'POST' '/api/invoice/documents/download' $istek
      $url = $r.metin.Trim().Trim('"')
      if ($r.kod -ne 200 -or $url -notmatch '^https://') { Yanit $ctx 502 (JsonMetin @{ hata = ('PDF bağlantısı alınamadı (' + $r.kod + ')') }); return }
      $wc = New-Object Net.WebClient
      try { $bayt = $wc.DownloadData($url) } finally { $wc.Dispose() }
      YanitBayt $ctx $bayt 'application/pdf'
    }
    '/xml' {
      # Faturanın UBL XML'ini verir (satır/kalem bilgileri için). tip: EFATURA | EARSIV | GELEN | GIDEN (GIDEN: önce e-Fatura, olmazsa e-Arşiv denenir)
      $g = $govde | ConvertFrom-Json
      Giris
      $turler = switch ($g.tip) { 'EFATURA' { @('EINVOICE') } 'GELEN' { @('INCOMING_EINVOICE') } 'GIDEN' { @('EINVOICE', 'EARCHIVE') } default { @('EARCHIVE') } }
      $url = $null; $sonKod = 0
      foreach ($dt in $turler) {
        $istek = JsonMetin @{ documentType = $dt; fileExtension = 'xml'; documentUuid = $g.uuid; companyId = $script:kimlik.companyId; inline = $true; envelope = $false }
        $r = TrendyolIstek 'POST' '/api/invoice/documents/download' $istek; $sonKod = $r.kod
        $u = $r.metin.Trim().Trim('"'); if ($r.kod -eq 200 -and $u -match '^https://') { $url = $u; break }
      }
      if (-not $url) { Yanit $ctx 502 (JsonMetin @{ hata = ('XML bağlantısı alınamadı (' + $sonKod + ')') }); return }
      $wc = New-Object Net.WebClient
      try { $bayt = $wc.DownloadData($url) } finally { $wc.Dispose() }
      YanitBayt $ctx $bayt 'application/xml; charset=utf-8'
    }
    '/indir' {
      $g = $govde | ConvertFrom-Json
      Giris
      $istek = JsonMetin @{ documentType = $(if ($g.tip -eq 'EFATURA') { 'EINVOICE' } elseif ($g.tip -eq 'GELEN') { 'INCOMING_EINVOICE' } else { 'EARCHIVE' }); fileExtension = 'pdf'; documentUuid = $g.uuid; companyId = $script:kimlik.companyId; inline = $true; envelope = $false }
      $r = TrendyolIstek 'POST' '/api/invoice/documents/download' $istek
      Yanit $ctx 200 (JsonMetin @{ kod = $r.kod; url = $r.metin.Trim().Trim('"') })
    }
    default { Yanit $ctx 404 (JsonMetin @{ hata = 'Bilinmeyen istek' }) }
  }
}

$l = New-Object Net.HttpListener
$l.Prefixes.Add("http://localhost:$PORT/")
$l.Prefixes.Add("http://127.0.0.1:$PORT/")
try { $l.Start() } catch { Log ('Başlatılamadı (zaten çalışıyor olabilir): ' + $_.Exception.Message); exit 1 }
Log ("Köprü başladı, port $PORT, sürüm $SURUM")
while ($l.IsListening) {
  $ctx = $l.GetContext()
  try { Isle $ctx }
  catch {
    $m = $_.Exception.Message; Log ('Hata: ' + $m)
    try { Yanit $ctx 500 (JsonMetin @{ hata = $m }) } catch {}
  }
}
