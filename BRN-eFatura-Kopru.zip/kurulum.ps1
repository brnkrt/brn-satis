﻿# BRN e-Fatura Köprüsü — kurulum
# Trendyol e-Faturam e-posta ve şifreniz bu bilgisayarda Windows'un kendi şifrelemesiyle (DPAPI) saklanır.
# Şifre ekranda görünmez ve hiçbir yere gönderilmez; yalnızca köprü Trendyol'a giriş yaparken kullanır.
$ErrorActionPreference = 'Stop'
$burasi = Split-Path -Parent $MyInvocation.MyCommand.Path
$klasor = Join-Path $env:APPDATA 'BRN-eFatura'
New-Item -ItemType Directory -Force $klasor | Out-Null
$ayarYol = Join-Path $klasor 'ayar.json'

Write-Host ''
Write-Host '  BRN e-Fatura Köprüsü — Kurulum' -ForegroundColor Cyan
Write-Host '  ------------------------------'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try { $ip = (Invoke-RestMethod 'https://api.ipify.org?format=json' -TimeoutSec 10).ip } catch { $ip = 'öğrenilemedi' }
Write-Host ('  Bu bilgisayarın internet (dış) adresi: ' + $ip) -ForegroundColor Yellow
Write-Host '  Bu adres Trendyol e-Faturam portalında Entegrasyon ekranında izinli IP olarak kayıtlı olmalı.'
Write-Host ''
Write-Host '  1) TEST ortamı   (deneme — gerçek fatura KESİLMEZ)'
Write-Host '  2) CANLI ortam   (GERÇEK fatura kesilir)'
$o = Read-Host '  Seçiminiz (1 veya 2)'
$ortam = if ($o.Trim() -eq '2') { 'canli' } else { 'test' }
if ($ortam -eq 'canli') { Write-Host '  CANLI ortam seçildi: BRN''den gönderilen faturalar gerçek olarak kesilecek.' -ForegroundColor Yellow }
else { Write-Host '  TEST ortamı seçildi. Şifre olarak, Trendyol''un gönderdiği e-postadaki bağlantıyla TEST ortamı için belirlediğiniz şifreyi girin.' -ForegroundColor Green }
$email = (Read-Host '  Trendyol e-Faturam e-posta adresiniz').Trim()
$sifre = Read-Host '  Şifreniz (yazarken görünmez)' -AsSecureString
@{ ortam = $ortam; email = $email; sifre = (ConvertFrom-SecureString $sifre) } | ConvertTo-Json | Set-Content -Path $ayarYol -Encoding UTF8
$sifre = $null
Write-Host '  Bilgiler kaydedildi.' -ForegroundColor Green

# Giriş denemesi
Write-Host '  Trendyol''a giriş deneniyor...'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try {
  $a = Get-Content -Raw -Encoding UTF8 $ayarYol | ConvertFrom-Json
  $taban = if ($a.ortam -eq 'canli') { 'https://apigateway.trendyolecozum.com' } else { 'https://stage-apigateway.trendyolefaturam.com' }
  $p = [Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $a.sifre))
  $g = @{ email = $a.email; password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p) } | ConvertTo-Json -Compress
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)
  $r = Invoke-WebRequest -UseBasicParsing -Method Post -Uri ($taban + '/api/auth/signin') -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($g))
  $g = $null
  Write-Host "  Giriş BAŞARILI ($ortam ortamı)." -ForegroundColor Green
} catch {
  $kod = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
  if ($kod -eq 403) { Write-Host '  Trendyol bu internet adresini engelledi (403). Portalda izinli IP adresini kontrol edin.' -ForegroundColor Red }
  elseif ($kod -eq 401 -or $kod -eq 400 -or $kod -eq 422) { Write-Host '  Giriş başarısız: e-posta veya şifre hatalı. KURULUM.cmd ile tekrar deneyin.' -ForegroundColor Red }
  else { Write-Host ('  Giriş denenemedi: ' + $_.Exception.Message) -ForegroundColor Red }
}

# Bilgisayar açılınca otomatik başlatma
$c = Read-Host '  Bilgisayar açılınca köprü kendiliğinden başlasın mı? (E/H)'
$baslangic = [Environment]::GetFolderPath('Startup')
$kisayol = Join-Path $baslangic 'BRN e-Fatura Köprüsü.lnk'
if ($c -match '^[eE]') {
  $ws = New-Object -ComObject WScript.Shell
  $k = $ws.CreateShortcut($kisayol)
  $k.TargetPath = 'powershell.exe'
  $k.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $burasi 'kopru.ps1') + '"'
  $k.WorkingDirectory = $burasi; $k.WindowStyle = 7; $k.Description = 'BRN e-Fatura Köprüsü'
  $k.Save()
  Write-Host '  Açılışta otomatik başlatma eklendi.' -ForegroundColor Green
} elseif (Test-Path $kisayol) { Remove-Item $kisayol -Force; Write-Host '  Açılışta otomatik başlatma kaldırıldı.' }

# Köprüyü yeniden başlat (yeni bilgilerle)
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*kopru.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $burasi 'kopru.ps1') + '"') -WindowStyle Hidden
Write-Host '  Köprü çalışıyor. BRN''de fatura ekranından "Trendyol''a gönder" kullanılabilir.' -ForegroundColor Cyan
Write-Host ''
